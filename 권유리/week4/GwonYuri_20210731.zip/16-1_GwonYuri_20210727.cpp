class Solution {
public:
    bool divisorGame(int n) 
    {
        if(n % 2 == 0)
            return true;
        else
            return false;
    }
};