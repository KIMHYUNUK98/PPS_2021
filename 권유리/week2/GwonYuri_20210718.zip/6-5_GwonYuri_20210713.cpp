#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
 
int main() {
	int n;
	int input;
	vector<int> arr;
 
	cin >> n;
	for (int i = 0; i < n; i++){
		cin >> input;
		arr.push_back(input);
	}
 
	sort(arr.begin(), arr.end());
	arr.erase(unique(arr.begin(), arr.end()), arr.end());
 
	for (int i=0; i<arr.size(); i++) cout << arr[i] << " ";
 
	cout << endl;
	return 0;
}